# AVR ASM Formatter (personal)

Formateador de columnas para ensamblador AVR (`label:` / mnemónico / operandos / `; comentario`), hecho a la medida porque ninguna extensión del marketplace maneja bien el direccionamiento indirecto de AVR (`X+`, `-Y`, `Z+q`).

## Por qué existe

Los formateadores genéricos que "normalizan espacios alrededor de + y -" rompen `X+`/`-Z` porque no saben que ahí `+`/`-` es parte del modo de direccionamiento, no un operador aritmético. Este formateador nunca reescribe el interior de un token — solo ajusta espacios *entre* campos (label, mnemónico, operandos, comentario) y entre operandos separados por coma.

## Uso

Con un archivo `.asm`/`.inc`/`.s` abierto: `Shift+Alt+F` (Format Document) o Ctrl+Shift+P → "AVR ASM: Format Document". También funciona con selección parcial (Format Selection) y con "Format on Save" si lo activas en tus settings para estos archivos.

## Configuración (settings.json)

```jsonc
"avrAsmFormatter.filePatterns": ["**/*.asm", "**/*.inc", "**/*.s", "**/*.S"],
"avrAsmFormatter.mnemonicColumn": 4,
"avrAsmFormatter.operandColumn": 12,
"avrAsmFormatter.commentColumn": 40,
"avrAsmFormatter.commentMinSpacing": 2,
"avrAsmFormatter.alignCommentOnlyLines": true,
"avrAsmFormatter.mnemonicCase": "preserve" // "preserve" | "upper" | "lower"
```

Ajusta las columnas a lo que se vea más parecido a AVR Studio en tu pantalla/tamaño de fuente.

## Qué garantiza

- Nunca toca caracteres dentro de un operando (`X+`, `-Z`, `Y+3`, `0x1F`, cadenas entre comillas quedan intactas).
- `;` y `,` dentro de cadenas (`"texto; con punto y coma"`) no se confunden con comentarios/separadores.
- Líneas en blanco se quedan realmente en blanco (sin tabs fantasma).
- `label: instruccion` en la misma línea se separa correctamente.
- Si una línea ya es más larga que la columna configurada, nunca genera padding negativo — cae a un espaciado mínimo en vez de romperse.

## Pruebas

`node test/format.test.js` corre la batería de casos (direccionamiento indirecto, comentarios con comillas, overflow de columnas, etc.) sin necesidad de abrir VS Code.

## Cómo modificarla

1. Abre esta carpeta como workspace en VS Code (File → Open Folder).
2. La lógica de formato vive en `src/formatter.js` (funciones puras, sin dependencia de `vscode`). La integración con el editor (comandos, settings, cuándo activarse) vive en `extension.js`. Los defaults y la definición de cada setting viven en `package.json` bajo `contributes.configuration`.
3. Para probar un cambio SIN empaquetar nada: presiona `F5` (ya incluí `.vscode/launch.json`). Se abre una segunda ventana de VS Code ("Extension Development Host") con tu versión modificada ya cargada — abre ahí un `.asm` y prueba `Shift+Alt+F`. Cada vez que edites el código, cierra y vuelve a abrir esa ventana (o `Ctrl+R`/`Cmd+R` dentro de ella) para recargarla con los cambios.
4. Para validar solo la lógica de columnas sin ni siquiera abrir VS Code: edita `src/formatter.js`, ajusta/agrega casos en `test/format.test.js`, y corre `node test/format.test.js`. Es la forma más rápida de iterar.
5. Cuando quede como quieres, empaca un `.vsix` nuevo:
   ```
   npx @vscode/vsce package --no-dependencies --allow-missing-repository
   ```
   (sube el `version` en `package.json`, ej. de `0.1.0` a `0.1.1`, para que VS Code lo reconozca como actualización).
6. Instala el nuevo `.vsix`: panel de Extensiones → "..." → "Install from VSIX..." → selecciona el archivo nuevo. Si la versión anterior sigue instalada con el mismo nombre/publisher, VS Code la reemplaza; si no, desinstala la vieja primero y reinicia la ventana (`Developer: Reload Window` desde Ctrl+Shift+P).
